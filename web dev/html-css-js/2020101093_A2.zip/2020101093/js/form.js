var dict = {};

function Form() {
    var A = document.forms["skillForm"]["Name"].value;
    /*if (A == "") {
        document.forms["skillForm"]["Name"].value = prompt("Did u forgot to put Your Name? If not u can put Anonymous.\(O.O\)");
        A = document.forms["skillForm"]["Name"].value;
    }*/
    var B = document.forms["skillForm"]["skillName"].value;
   /* if (B == "") {
        document.forms["skillForm"]["skillName"].value = prompt("Did u forgot to put it? If not u can put None. :) ");
        B = document.forms["skillForm"]["skillName"].value;
    }*/
    var l = document.getElementById("prof");
    var C = l.options[l.selectedIndex].text;
    var check = "ThisIsFormData";
    dict[A] = { B, C, check };
    document.getElementById('InsertHere').innerHTML += '<tr><td > ' + A + '</td><td>' + B +
        '</td><td>' + C + '</td></tr>';
    document.getElementById("name").value = "";
    document.getElementById("skill").value = "";
     document.getElementById("prof").value = "";
    return false;
}