function change_image() {
    var x = document.getElementById('changingimage')
    var str = document.getElementById('changingimage').src;
    if (str.includes("cat2.jfif")) {
        x.src = "../img/cat3.jfif";
    } else if (str.includes("cat3.jfif")) {
        x.src = "../img/pic3.jpeg";
    } else if (str.includes("pic3.jpeg")) {
        x.src = "../img/pic4.jpeg";
    } else if (str.includes("pic4.jpeg")) {
        x.src = "../img/pic5.jpeg";
    } else if (str.includes("pic5.jpeg")) {
        x.src = "../img/cat2.jfif";
    } else {
        x.src = "";
    }
}