//hovering using jQuery

$(document).ready(function(){
  $("a").hover(function(){
    $(this).css("color", "green");
    }, function(){
    $(this).css("color", "hotpink");
  });
});
