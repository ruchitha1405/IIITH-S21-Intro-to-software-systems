$(document).ready(function() {
    $(document).scroll(function() {
        $('.abc').css({ "position": "fixed", "z-index": "1000" });
    });
});
//this is for when i hover into the navigation bar's elements to change their color 
$(document).ready(function() {
    $(".hover").on({
        mouseenter: function() {
            $(this).css('background-color', 'blue');
        },
        mouseleave: function() {
            $(this).css('background-color', '');
        },
    });
});
//this is for those gallery images 
let x = 1;

function check() {
    console.log(document.getElementById("image").src);

    if (document.getElementById("image").src = "../img/t1.jpg" && (x % 5) == 1) {
        document.getElementById("image").src = "../img/t2.jpg";
        x += 1;
    } else if (document.getElementById("image").src = "../img/t2.jpg" && (x % 5) == 2) {
        document.getElementById("image").src = "../img/t3.jpg";
        x += 1;
    } else if (document.getElementById("image").src = "../img/t3.jpg" && (x % 5) == 3) {
        document.getElementById("image").src = "../img/t4.jpg";
        x += 1;
    } else if (document.getElementById("image").src = "../img/t4.jpg" && (x % 5) == 4) {
        document.getElementById("image").src = "../img/t5.jpg";
        x += 1;
    } else if (document.getElementById("image").src = "../img/t5.jpg" && (x % 5) == 0) {
        document.getElementById("image").src = "../img/t1.jpg";
        x += 1;
    };
}
//this is for the form thingy
var dict = {};

function Form() {
    var A = document.forms["skillForm"]["Name"].value;
    if (A == "") {
        document.forms["skillForm"]["Name"].value = prompt("Did u forgot to put Your Name? If not u can put Anonymous.\(O.O\)");
        A = document.forms["skillForm"]["Name"].value;
    }
    var B = document.forms["skillForm"]["skill"].value;
    if (B == "") {
        document.forms["skillForm"]["skill"].value = prompt("Did u forgot to put it? If not u can put None. :) ");
        B = document.forms["skillForm"]["skill"].value;
    }
    var l = document.getElementById("dropdown");
    var C = l.options[l.selectedIndex].text;
    var check = "ThisIsFormData";
    dict[A] = { B, C, check };
    document.getElementById('InsertHere').innerHTML += '<tr><td class = "pl-5 text-white"> ' + A + '</td><td class="pl-5">' + B +
        '</td><td class="pl-5">' + C + '</td></tr>';
    document.getElementById("Name").value = "";
    document.getElementById("skill").value = "";
    return false;
}